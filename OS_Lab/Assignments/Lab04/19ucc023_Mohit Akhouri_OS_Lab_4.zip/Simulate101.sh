#!/bin/bash

# Roll no = 19ucc023
# Name = Mohit Akhouri
# OS LAB Batch - Wednesday ( 2-4 pm )
# OS LAB Assignment 4 

#checking if total number of arguments = 4
if [ $# -lt 4 ]
then
	echo "Invalid number of arguments supplied to the script"
	exit -1
fi


#defining arrays for the parameters supplied to the script
Problem_Size=(2000 3000 4000 5000 6000 7000 8000)
Page_Frame_Size=(16 32 64 128 256)
Page_Frame_Count=(16 32 64 128 256 512)
Policy=("FIFO" "NRU" "LRU" "Opt")

check() #creating function to check the validity of different arguments
{
	if [ $1 = "Problem_Size" ]
	then
		for i in ${Problem_Size[@]}
		do
			if [ $2 -eq $i ]
			then
				return 1
			fi
		done
	elif [ $1 = "Page_Frame_Size" ]
	then
		for i in ${Page_Frame_Size[@]}
		do
			if [ $2 -eq $i ]
			then
				return 1
			fi
		done
	elif [ $1 = "Page_Frame_Count" ]
	then
		for i in ${Page_Frame_Count[@]}
		do
			if [ $2 -eq $i ]
			then
				return 1
			fi
		done
	elif [ $1 = "Policy" ]
	then
		for i in ${Policy[@]}
		do
			if [ $2 = $i ]
			then
				return 1
			fi
		done
	else
		echo "Wrong arguments supplied"
	fi
	return 0
}

flag="1"
check Problem_Size $1
if [ $? -eq 0 ]
then
	echo "Invalid value for the Problem Size !"
	flag="0"
fi

check Page_Frame_Size $2
if [ $? -eq 0 ]
then
	echo "Invalid value for the Page-Frame-Size !"
	flag="0"
fi

check Page_Frame_Count $3
if [ $? -eq 0 ]
then
	echo "Invalid value for the Page-Frame-count !"
	flag="0"
fi

check Policy $4
if [ $? -eq 0 ]
then
	echo "Invalid value for the Policy used !"
	flag="0"
fi

if [ $flag = "0" ]
then
	exit -1
fi


# command substitution to find two numerical values "Disk reads" and "Disk writes" and store them in variable DISKIO
DISKIO=$(./nameSorter $1 listaccess | ./pageRefGen $2 | ./$4 $3 | grep -i "disk" | tr -dc '0-9 ')


#deriving values for DiskReads and DiskWrites
c=1
for i in $DISKIO
do
	if [ $c -eq 1 ]
	then
		DiskReads=$i
	else
		DiskWrites=$i
	fi
	c=`expr $c + 1`
done

#calculating the total disk activity and printing it
DiskActivity=`expr $DiskReads + $DiskWrites`
echo $DiskActivity

