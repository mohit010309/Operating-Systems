Roll no = 19ucc023
Name = Mohit Akhouri
OS LAB Assignment 4

To call the scripts Simulate.sh and Simulate101.sh , save the programs in same directory and use :

./Simulate.sh <Problem-Size> <Page-Frame-Size> <Page-Frame-Count> <Policy>

./Simulate101.sh <Problem-Size> <Page-Frame-Size> <Page-Frame-Count> <Policy>