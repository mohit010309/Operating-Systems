#!/bin/bash

# Roll no = 19ucc023
# Name = Mohit Akhouri
# OS LAB Batch - Wednesday ( 2-4 pm )
# OS LAB Assignment 4 

#checking if total number of arguments = 4
if [ $# -lt 4 ]
then
	echo "Invalid number of arguments supplied to the script"
	exit -1
fi

#checking for count of 'All'
arguments=$*
co=0
for i in $arguments
do
	if [ $i = "All" ]
	then
		co=`expr $co + 1`
	fi
done
if [ $co -gt 1 ]
then
	echo "Only one argument is allowed to be All"
	exit -1
fi

#defining arrays for the parameters supplied to the script
Problem_Size=(2000 3000 4000 5000 6000 7000 8000)
Page_Frame_Size=(16 32 64 128 256)
Page_Frame_Count=(16 32 64 128 256 512)
Policy=("FIFO" "NRU" "LRU" "Opt")

#creating function to check the validity of different arguments
check()
{
	if [ $1 = "Problem_Size" ]
	then
		for i in ${Problem_Size[@]}
		do
			if [ $2 -eq $i ]
			then
				return 1
			fi
		done
	elif [ $1 = "Page_Frame_Size" ]
	then
		for i in ${Page_Frame_Size[@]}
		do
			if [ $2 -eq $i ]
			then
				return 1
			fi
		done
	elif [ $1 = "Page_Frame_Count" ]
	then
		for i in ${Page_Frame_Count[@]}
		do
			if [ $2 -eq $i ]
			then
				return 1
			fi
		done
	elif [ $1 = "Policy" ]
	then
		for i in ${Policy[@]}
		do
			if [ $2 = $i ]
			then
				return 1
			fi
		done
	else
		echo "Wrong arguments supplied"
	fi
	return 0
}

flag="1"
if [ $1 != 'All' ]
then
	check Problem_Size $1
	if [ $? -eq 0 ]
	then
		echo "Invalid value for the Problem Size !"
		flag="0"
	fi
else
	ind=1
fi

if [ $2 != 'All' ]
then
	check Page_Frame_Size $2
	if [ $? -eq 0 ]
	then
		echo "Invalid value for the Page-Frame-Size !"
		flag="0"
	fi
else
	ind=2
fi

if [ $3 != 'All' ]
then
	check Page_Frame_Count $3
	if [ $? -eq 0 ]
	then
		echo "Invalid value for the Page-Frame-count !"
		flag="0"
	fi
else
	ind=3
fi

if [ $4 != 'All' ]
then
	check Policy $4
	if [ $? -eq 0 ]
	then
		echo "Invalid value for the Policy used !"
		flag="0"
	fi
else
	ind=4
fi

if [ $flag = "0" ]
then
	exit -1
fi

#main algorithm for Simulate.sh starts here

#ind stores the argument number that is marked "All"
# -e to use special characters
# -n to stay on same line

if [ $ind -eq 1 ]
then
	echo "Page-Frame-Size = $2 ,  Page-Frame-Count = $3 ,  Policy = $4"
	echo
	echo -e "Problem-Size\tTotal Disk Activity"
	echo
	for i in ${Problem_Size[@]}
	do
		echo -n -e "$i\t\t"     
		bash ./Simulate101.sh $i $2 $3 $4 #calling Simulate101.sh
	done
elif [ $ind -eq 2 ]
then
	echo "Problem-Size = $1 ,  Page-Frame-Count = $3 ,  Policy = $4"
	echo
	echo -e "Page-Frame-Size\tTotal Disk Activity"
	echo
	for i in ${Page_Frame_Size[@]}
	do
		echo -n -e "$i\t\t"     
		bash ./Simulate101.sh $1 $i $3 $4 #calling Simulate101.sh
	done
elif [ $ind -eq 3 ]
then
	echo "Problem-Size = $1 ,  Page-Frame-Size = $2 ,  Policy = $4"
	echo
	echo -e "Page-Frame-Count\tTotal Disk Activity"
	echo
	for i in ${Page_Frame_Count[@]}
	do
		echo -n -e "$i\t\t"     
		bash ./Simulate101.sh $1 $2 $i $4 #calling Simulate101.sh
	done
elif [ $ind -eq 4 ]
then
	echo "Problem-Size = $1 ,  Page-Frame-Size = $2 ,  Page-Frame-Count = $3"
	echo
	echo -e "Policy\tTotal Disk Activity" 
	echo
	for i in ${Policy[@]}
	do
		echo -n -e "$i\t\t"     
		bash ./Simulate101.sh $1 $2 $3 $i #calling Simulate101.sh
	done
else
	bash ./Simulate101.sh $1 $2 $3 $4 #calling Simulate101.sh
fi
	

