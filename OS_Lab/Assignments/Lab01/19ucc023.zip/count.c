//19ucc023
//Mohit Akhouri
//OS Lab ( Wednesday Batch ( 2-4 pm) )
//OS_Lab 1 = Task B
//January 20, 2021
#include <stdio.h>
#include <stdlib.h>
int main(int argc,char *argv[])//argc for count of arguments and argv to store arguments
{
	char ch; //to check for characters that are given as input
	int co=0; //to store count of characters
	do
	{
		ch=getchar();
		if(ch==EOF)
		{
			fprintf(stderr,"final count = %d\n",co);
			exit(0);
		}
		else if(!((ch>='A' && ch<='Z')||(ch>='a' && ch<='z')))
		{
			co++;
		}
		putchar(ch);
	}while(1);
}
			
