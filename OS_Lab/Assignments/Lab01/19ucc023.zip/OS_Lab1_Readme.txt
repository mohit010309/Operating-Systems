19ucc023
Mohit Akhouri
OS_Lab 1 ( 20 january, 2021 )

count = Task B
convert = Task C
file1.txt = .txt file 
running the command for taskD as :
./a.out file1.txt file2.txt