//19ucc023
//Mohit Akhouri
//OS Lab ( Wednesday Batch ( 2-4 pm) )
//OS_Lab 1 = Task A
//January 20, 2021
#include <stdio.h>
int main(int argc,char *argv[])//argc for count of arguments and argv to store arguments
{
	int i;
	int flag=0; //to check if there is atleast 1 non-dash argument
	if(argc-1!=0)
	{
		for(i=1;i<argc;i++)
		{
			if(argv[i][0]!='-')
			{
				flag=1;
				printf("%s ",argv[i]);
			}
		}
		if(flag==1)
			printf("\n");
	}
}
