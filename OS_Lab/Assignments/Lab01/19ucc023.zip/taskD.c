//19ucc023
//Mohit Akhouri
//OS Lab ( Wednesday Batch ( 2-4 pm) )
//OS_Lab 1 = Task D
//January 20, 2021
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h>
#include <ctype.h>
#include <errno.h>
int main(int argc,char *argv[])//argc for count of arguments and argv to store arguments
{
	int fd_in,fd_out;
	//checking for exactly 3 arguments
	if(argc<3)
	{
		fprintf(stderr,"%s\n","Less number of arguments");
		exit(1);
	}
	fd_in=open(argv[1],O_RDONLY);
	if(fd_in==-1)
	{
		fprintf(stderr,"%s\n","Error opening file 1");
		exit(1);
	}
	fd_out=creat(argv[2],0644);
	if(fd_out==-1)
	{
		fprintf(stderr,"%s\n","File 2 could not be created");
		exit(1);
	}
	//stdin is now file 1
	close(0);
	dup(fd_in);
	close(fd_in);
	//stdout is now file 2
	close(1);
	dup(fd_out);
	close(fd_out);
	//creating pipe
	int fd[2];
	int status;
	if(pipe(fd)==-1) //to check if creation of pipe failed
	{
		fprintf(stderr,"%s\n","Pipe could not be created");
		exit(1);
	}
	//forking starts here
	if(fork()!=0) //This is parent
	{
		if(fork()!=0) //This is parent
		{
			close(fd[0]);
			close(fd[1]);
			wait(&status);
			wait(&status);
			exit(0);
		}
		else //This is second child
		{
			close(fd[0]);
			close(1);
			dup(fd[1]);
			execl("convert","convert",(char *)0);
			close(fd[1]);
		}
	}
	else //This is first child
	{
		close(fd[1]);
		close(0);
		dup(fd[0]);
		execl("count","count",(char *)0);
		close(fd[0]);
	}
			
}
