//19ucc023
//Mohit Akhouri
//OS Lab ( Wednesday Batch ( 2-4 pm) )
//OS_Lab 1 = Task C
//January 20, 2021
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
int main(int argc,char *argv[])//argc for count of arguments and argv to store arguments
{
	int co;
	char ch;
	int flag; //to check whether character is uppercase or lowercase
	do
	{
		ch=getchar();
		if(ch==EOF)
		{
			exit(0);
		}
		else if(isalpha(ch))
		{
			if(isupper(ch))
				flag=1;
			else
				flag=2;
			co=0;
			while(co!=13) //loop for encoding till 13 places
			{
				ch++;
				if(flag==1 && ch>'Z')
					ch='A';
				else if(flag==2 && ch>'z')
					ch='a';
				co++;
			}
		}
		putchar(ch);
	}while(1);
}
